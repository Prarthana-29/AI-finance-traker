import React from 'react';
import { motion } from 'framer-motion';
import { Github, Linkedin, Mail, Sparkles, Code2 } from 'lucide-react';

const teamMembers = [
  {
    name: 'Developer Name',
    role: 'Full Stack Developer & ML Engineer',
    bio: 'Built the complete AI-powered finance tracking system with React.js frontend and Python ML backend.',
    github: 'https://github.com',
    linkedin: 'https://linkedin.com',
    email: 'developer@example.com',
    initials: 'DN',
    color: '#00D4FF'
  },
  {
    name: 'Team Member 2',
    role: 'Data Scientist',
    bio: 'Led dataset analysis, feature engineering, and model optimization for the prediction engine.',
    github: 'https://github.com',
    linkedin: 'https://linkedin.com',
    email: 'data@example.com',
    initials: 'TM',
    color: '#8B5CF6'
  },
  {
    name: 'Team Member 3',
    role: 'UI/UX Designer',
    bio: 'Designed the futuristic interface with glassmorphism effects, animations, and responsive layouts.',
    github: 'https://github.com',
    linkedin: 'https://linkedin.com',
    email: 'design@example.com',
    initials: 'UD',
    color: '#34D399'
  }
];

const TeamSection = () => {
  return (
    <section id="team" className="relative z-10 py-20 section-padding">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8 }}
      >
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-neon-purple/10 border border-neon-purple/30 mb-4"
          >
            <Code2 className="w-4 h-4 text-neon-purple" />
            <span className="text-sm text-neon-purple font-medium">Meet The Team</span>
          </motion.div>
          <h2 className="font-poppins text-4xl md:text-5xl font-bold text-white mb-4">
            Our <span className="text-gradient">Developers</span>
          </h2>
          <p className="text-white/50 max-w-2xl mx-auto">
            A passionate team of developers, data scientists, and designers building the future of personal finance.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {teamMembers.map((member, index) => (
            <motion.div
              key={index}
              className="glass-card-strong p-8 text-center group"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
              whileHover={{ 
                y: -10, 
                boxShadow: `0 0 40px ${member.color}20`,
                borderColor: `${member.color}40`
              }}
            >
              {/* Avatar */}
              <motion.div
                className="w-24 h-24 rounded-full mx-auto mb-6 flex items-center justify-center text-2xl font-bold text-white"
                style={{ 
                  background: `linear-gradient(135deg, ${member.color}30, ${member.color}10)`,
                  border: `2px solid ${member.color}40`
                }}
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                {member.initials}
              </motion.div>

              <h3 className="text-xl font-semibold text-white mb-1">{member.name}</h3>
              <p className="text-sm font-medium mb-4" style={{ color: member.color }}>
                {member.role}
              </p>
              <p className="text-white/50 text-sm mb-6 leading-relaxed">
                {member.bio}
              </p>

              {/* Social Links */}
              <div className="flex justify-center gap-3">
                <motion.a
                  href={member.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/50 hover:text-white hover:bg-white/10 transition-all"
                  whileHover={{ scale: 1.1, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Github className="w-5 h-5" />
                </motion.a>
                <motion.a
                  href={member.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/50 hover:text-white hover:bg-white/10 transition-all"
                  whileHover={{ scale: 1.1, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Linkedin className="w-5 h-5" />
                </motion.a>
                <motion.a
                  href={`mailto:${member.email}`}
                  className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/50 hover:text-white hover:bg-white/10 transition-all"
                  whileHover={{ scale: 1.1, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Mail className="w-5 h-5" />
                </motion.a>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
};

export default TeamSection;
