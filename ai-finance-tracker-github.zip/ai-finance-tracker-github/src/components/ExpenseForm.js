import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  DollarSign, Wallet, Tag, CreditCard, Target, 
  PiggyBank, Calendar, ShoppingCart, Brain, 
  ChevronRight, AlertCircle, Loader2, TrendingUp
} from 'lucide-react';
import { predictSpending, getRecommendations, datasetInfo } from '../data/financeData';
import PredictionResults from './PredictionResults';

const ExpenseForm = () => {
  const [formData, setFormData] = useState({
    income: '',
    expenseAmount: '',
    category: 'Food',
    paymentMethod: 'Credit Card',
    budgetLimit: '',
    savingsGoal: '',
    date: new Date().toISOString().split('T')[0],
    spendingType: 'Need'
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [showResult, setShowResult] = useState(false);

  const inputFields = [
    { name: 'income', label: 'Monthly Income', unit: 'USD', icon: DollarSign, placeholder: '4500', min: 0, type: 'number' },
    { name: 'expenseAmount', label: 'Expense Amount', unit: 'USD', icon: Wallet, placeholder: '150', min: 0, type: 'number' },
    { name: 'budgetLimit', label: 'Budget Limit', unit: 'USD', icon: Target, placeholder: '3000', min: 0, type: 'number' },
    { name: 'savingsGoal', label: 'Savings Goal', unit: 'USD', icon: PiggyBank, placeholder: '1000', min: 0, type: 'number' },
    { name: 'date', label: 'Date', unit: '', icon: Calendar, type: 'date' },
  ];

  const selectFields = [
    { name: 'category', label: 'Category', icon: Tag, options: datasetInfo.categories },
    { name: 'paymentMethod', label: 'Payment Method', icon: CreditCard, options: datasetInfo.paymentMethods },
    { name: 'spendingType', label: 'Spending Type', icon: ShoppingCart, options: datasetInfo.spendingTypes },
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.income || parseFloat(formData.income) <= 0) {
      newErrors.income = 'Valid income is required';
    }
    if (!formData.expenseAmount || parseFloat(formData.expenseAmount) <= 0) {
      newErrors.expenseAmount = 'Valid expense amount is required';
    }
    if (!formData.budgetLimit || parseFloat(formData.budgetLimit) <= 0) {
      newErrors.budgetLimit = 'Valid budget limit is required';
    }
    if (!formData.savingsGoal || parseFloat(formData.savingsGoal) < 0) {
      newErrors.savingsGoal = 'Valid savings goal is required';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    setShowResult(false);

    await new Promise(resolve => setTimeout(resolve, 2000));

    const numericData = {};
    Object.keys(formData).forEach(key => {
      numericData[key] = ['income', 'expenseAmount', 'budgetLimit', 'savingsGoal'].includes(key) 
        ? parseFloat(formData[key]) || 0 
        : formData[key];
    });

    const prediction = predictSpending(numericData);
    const recommendations = getRecommendations(prediction, numericData);

    setResult({
      ...prediction,
      recommendations,
      formData: numericData
    });

    setLoading(false);
    setShowResult(true);
  };

  return (
    <section id="track" className="relative z-10 py-20 section-padding">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8 }}
      >
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-neon-blue/10 border border-neon-blue/30 mb-4"
          >
            <Brain className="w-4 h-4 text-neon-blue" />
            <span className="text-sm text-neon-blue font-medium">AI Prediction Engine</span>
          </motion.div>
          <h2 className="font-poppins text-4xl md:text-5xl font-bold text-white mb-4">
            Track Your <span className="text-gradient">Expenses</span>
          </h2>
          <p className="text-white/50 max-w-2xl mx-auto">
            Enter your financial details below. Our AI model will analyze your spending patterns and predict your monthly expenses with high accuracy.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <motion.div
            className="glass-card-strong p-6 md:p-10"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
                {inputFields.map((field, index) => (
                  <motion.div
                    key={field.name}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.05 }}
                  >
                    <label className="block text-sm font-medium text-white/70 mb-2 flex items-center gap-2">
                      <field.icon className="w-4 h-4 text-neon-blue" />
                      {field.label}
                      {field.unit && <span className="text-white/30 text-xs">({field.unit})</span>}
                    </label>
                    <div className="relative">
                      <input
                        type={field.type}
                        step={field.type === 'number' ? '0.01' : undefined}
                        name={field.name}
                        value={formData[field.name]}
                        onChange={handleChange}
                        placeholder={field.placeholder}
                        className={`w-full input-glow ${errors[field.name] ? 'border-red-500 focus:border-red-500 focus:shadow-[0_0_20px_rgba(239,68,68,0.3)]' : ''}`}
                      />
                    </div>
                    <AnimatePresence>
                      {errors[field.name] && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="flex items-center gap-1 mt-1 text-red-400 text-xs"
                        >
                          <AlertCircle className="w-3 h-3" />
                          {errors[field.name]}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                ))}

                {selectFields.map((field, index) => (
                  <motion.div
                    key={field.name}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: (index + 5) * 0.05 }}
                  >
                    <label className="block text-sm font-medium text-white/70 mb-2 flex items-center gap-2">
                      <field.icon className="w-4 h-4 text-neon-blue" />
                      {field.label}
                    </label>
                    <div className="relative">
                      <select
                        name={field.name}
                        value={formData[field.name]}
                        onChange={handleChange}
                        className="w-full input-glow appearance-none cursor-pointer"
                      >
                        {field.options.map((option) => (
                          <option key={option} value={option} className="bg-bg-dark text-white">
                            {option}
                          </option>
                        ))}
                      </select>
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                        <ChevronRight className="w-4 h-4 text-white/40 rotate-90" />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <motion.div
                className="mt-8 flex justify-center"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
              >
                <motion.button
                  type="submit"
                  disabled={loading}
                  className="btn-primary flex items-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
                  whileHover={{ scale: loading ? 1 : 1.05 }}
                  whileTap={{ scale: loading ? 1 : 0.95 }}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      AI Analyzing...
                    </>
                  ) : (
                    <>
                      <Brain className="w-5 h-5" />
                      Predict Spending
                      <ChevronRight className="w-5 h-5" />
                    </>
                  )}
                </motion.button>
              </motion.div>
            </form>
          </motion.div>
        </div>

        <AnimatePresence>
          {showResult && result && (
            <PredictionResults result={result} formData={formData} />
          )}
        </AnimatePresence>
      </motion.div>
    </section>
  );
};

export default ExpenseForm;
