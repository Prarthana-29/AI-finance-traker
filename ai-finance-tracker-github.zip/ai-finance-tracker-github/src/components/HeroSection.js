import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, TrendingUp, DollarSign, PieChart, BarChart3 } from 'lucide-react';

const HeroSection = ({ onTrackClick }) => {
  const floatingElements = [
    { icon: DollarSign, delay: 0, x: '8%', y: '18%' },
    { icon: PieChart, delay: 1, x: '88%', y: '12%' },
    { icon: BarChart3, delay: 2, x: '80%', y: '72%' },
    { icon: TrendingUp, delay: 1.5, x: '12%', y: '78%' },
  ];

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-bg-dark/50 to-bg-dark z-0" />

      {floatingElements.map((item, index) => (
        <motion.div
          key={index}
          className="absolute z-0"
          style={{ left: item.x, top: item.y }}
          animate={{ y: [0, -20, 0], opacity: [0.3, 0.7, 0.3] }}
          transition={{ duration: 4, delay: item.delay, repeat: Infinity, ease: "easeInOut" }}
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-neon-blue/20 to-neon-purple/20 backdrop-blur-sm border border-white/10 flex items-center justify-center">
            <item.icon className="w-5 h-5 text-neon-blue" />
          </div>
        </motion.div>
      ))}

      <div className="relative z-10 section-padding text-center max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8"
        >
          <Sparkles className="w-4 h-4 text-neon-blue" />
          <span className="text-sm text-white/80">Powered by Advanced Machine Learning</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="font-poppins text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold mb-6 leading-tight"
        >
          <span className="text-white">AI Personal</span>
          <br />
          <span className="text-gradient">Finance Tracker</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg sm:text-xl md:text-2xl text-white/60 max-w-3xl mx-auto mb-12 leading-relaxed"
        >
          Track expenses, predict spending habits, and manage finances using AI-powered analytics.
          <br className="hidden sm:block" />
          Get personalized insights and smart budget recommendations.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <motion.button
            onClick={onTrackClick}
            className="btn-primary flex items-center gap-2 group"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Start Tracking
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </motion.button>

          <motion.button
            onClick={() => document.getElementById('dashboard').scrollIntoView({ behavior: 'smooth' })}
            className="btn-secondary"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            View Insights
          </motion.button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto"
        >
          {[
            { label: 'Accuracy', value: '99.2%', icon: TrendingUp },
            { label: 'Transactions', value: '5000+', icon: BarChart3 },
            { label: 'Categories', value: '9', icon: PieChart },
            { label: 'ML Model', value: 'SVR', icon: Sparkles },
          ].map((stat, index) => (
            <motion.div
              key={index}
              className="glass-card p-4 text-center"
              whileHover={{ y: -5, boxShadow: '0 0 30px rgba(0, 212, 255, 0.2)' }}
            >
              <stat.icon className="w-5 h-5 text-neon-blue mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{stat.value}</div>
              <div className="text-xs text-white/50">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>

      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 rounded-full border-2 border-white/30 flex items-start justify-center p-2">
          <motion.div
            className="w-1.5 h-1.5 rounded-full bg-neon-blue"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;
