import React from 'react';
import { motion } from 'framer-motion';
import { 
  Database, Brain, Code2, BarChart3, GitBranch, 
  Layers, Cpu, FileCode, Sparkles
} from 'lucide-react';

const techStack = [
  { name: 'Python', icon: FileCode, color: '#00D4FF', category: 'Backend' },
  { name: 'Pandas', icon: Database, color: '#8B5CF6', category: 'Data Processing' },
  { name: 'Scikit-learn', icon: Brain, color: '#34D399', category: 'ML Library' },
  { name: 'React.js', icon: Code2, color: '#22D3EE', category: 'Frontend' },
  { name: 'Tailwind CSS', icon: Layers, color: '#F472B6', category: 'Styling' },
  { name: 'Framer Motion', icon: Sparkles, color: '#FBBF24', category: 'Animation' },
  { name: 'Recharts', icon: BarChart3, color: '#EF4444', category: 'Charts' },
  { name: 'Git', icon: GitBranch, color: '#A78BFA', category: 'Version Control' },
];

const timelineSteps = [
  {
    step: '01',
    title: 'Data Collection',
    description: 'Personal Finance Dataset from Kaggle with 5000+ transactions across 9 expense categories.',
    icon: Database
  },
  {
    step: '02',
    title: 'Data Preprocessing',
    description: 'Cleaned and normalized data using Pandas. Handled missing values and encoded categorical variables.',
    icon: Layers
  },
  {
    step: '03',
    title: 'Feature Engineering',
    description: 'Extracted key features: Income, Expense Amount, Category, Payment Method, Budget Limit, and Savings Goal.',
    icon: Cpu
  },
  {
    step: '04',
    title: 'Model Training',
    description: 'Trained Support Vector Regression (SVR) model with RBF kernel achieving 99.2% R² score.',
    icon: Brain
  },
  {
    step: '05',
    title: 'Frontend Development',
    description: 'Built responsive React.js interface with Tailwind CSS, Framer Motion animations, and Recharts visualizations.',
    icon: Code2
  }
];

const AboutSection = () => {
  return (
    <section id="about" className="relative z-10 py-20 section-padding">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8 }}
      >
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-neon-blue/10 border border-neon-blue/30 mb-4"
          >
            <Brain className="w-4 h-4 text-neon-blue" />
            <span className="text-sm text-neon-blue font-medium">About The AI Model</span>
          </motion.div>
          <h2 className="font-poppins text-4xl md:text-5xl font-bold text-white mb-4">
            How It <span className="text-gradient">Works</span>
          </h2>
          <p className="text-white/50 max-w-2xl mx-auto">
            Built on a robust machine learning pipeline using real-world financial data to deliver accurate predictions.
          </p>
        </div>

        {/* Dataset Info Card */}
        <motion.div
          className="glass-card-strong p-8 max-w-4xl mx-auto mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-neon-blue/10 flex items-center justify-center mx-auto mb-4">
                <Database className="w-8 h-8 text-neon-blue" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-1">5,000+</h3>
              <p className="text-white/50 text-sm">Transaction Records</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-neon-purple/10 flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="w-8 h-8 text-neon-purple" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-1">9</h3>
              <p className="text-white/50 text-sm">Expense Categories</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-green-400/10 flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-green-400" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-1">99.2%</h3>
              <p className="text-white/50 text-sm">Model Accuracy (R²)</p>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-white/10">
            <h4 className="text-lg font-semibold text-white mb-3">Dataset Features</h4>
            <div className="flex flex-wrap gap-2">
              {['Income', 'Expense Amount', 'Category', 'Payment Method', 'Budget Limit', 'Savings Goal', 'Date', 'Spending Type'].map((feature) => (
                <span 
                  key={feature}
                  className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm text-white/70"
                >
                  {feature}
                </span>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Timeline */}
        <div className="max-w-4xl mx-auto mb-16">
          <h3 className="text-2xl font-bold text-white text-center mb-12">Development Pipeline</h3>
          <div className="relative">
            {/* Vertical line */}
            <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-neon-blue via-neon-purple to-neon-cyan hidden md:block" />

            {timelineSteps.map((step, index) => (
              <motion.div
                key={index}
                className={`relative flex items-start gap-6 mb-12 ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <div className="hidden md:block w-1/2" />

                {/* Center dot */}
                <div className="absolute left-8 md:left-1/2 -translate-x-1/2 w-12 h-12 rounded-full bg-bg-dark border-2 border-neon-blue flex items-center justify-center z-10">
                  <span className="text-xs font-bold text-neon-blue">{step.step}</span>
                </div>

                <div className="ml-20 md:ml-0 md:w-1/2 md:px-12">
                  <motion.div
                    className="glass-card p-6"
                    whileHover={{ y: -3, boxShadow: '0 0 30px rgba(0, 212, 255, 0.15)' }}
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-xl bg-neon-blue/10 flex items-center justify-center">
                        <step.icon className="w-5 h-5 text-neon-blue" />
                      </div>
                      <h4 className="text-lg font-semibold text-white">{step.title}</h4>
                    </div>
                    <p className="text-white/50 text-sm">{step.description}</p>
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Tech Stack */}
        <div className="max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold text-white text-center mb-8">Technology Stack</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {techStack.map((tech, index) => (
              <motion.div
                key={index}
                className="glass-card p-4 text-center group cursor-pointer"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                whileHover={{ 
                  y: -5, 
                  boxShadow: `0 0 30px ${tech.color}20`,
                  borderColor: `${tech.color}40`
                }}
              >
                <tech.icon 
                  className="w-8 h-8 mx-auto mb-3 transition-all duration-300 group-hover:scale-110" 
                  style={{ color: tech.color }}
                />
                <h4 className="text-sm font-semibold text-white mb-1">{tech.name}</h4>
                <p className="text-xs text-white/40">{tech.category}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </section>
  );
};

export default AboutSection;
