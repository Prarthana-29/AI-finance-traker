import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, DollarSign, Target, PiggyBank, Zap, Award,
  AlertTriangle, Lightbulb, TrendingDown, ArrowUpRight,
  ShoppingCart, Wallet, BarChart3
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';

const CircularProgress = ({ value, max, color, size = 180, strokeWidth = 12, label, sublabel }) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = Math.min((value / max) * circumference, circumference);

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth={strokeWidth} />
        <motion.circle
          cx={size/2} cy={size/2} r={radius} fill="none" stroke={color} strokeWidth={strokeWidth}
          strokeLinecap="round"
          initial={{ strokeDasharray: `0 ${circumference}` }}
          animate={{ strokeDasharray: `${progress} ${circumference}` }}
          transition={{ duration: 2, ease: "easeOut" }}
          style={{ filter: `drop-shadow(0 0 10px ${color})` }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <motion.span className="text-2xl font-bold text-white" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
          {label || value}
        </motion.span>
        <span className="text-xs text-white/50">{sublabel}</span>
      </div>
    </div>
  );
};

const PredictionResults = ({ result, formData }) => {
  const [animatedValues, setAnimatedValues] = useState({ spending: 0, savings: 0, budget: 0 });

  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const spendingInc = result.predictedSpending / steps;
    const savingsInc = result.actualSavings / steps;
    const budgetInc = result.budgetUsed / steps;
    let current = { spending: 0, savings: 0, budget: 0 };

    const timer = setInterval(() => {
      current.spending += spendingInc;
      current.savings += savingsInc;
      current.budget += budgetInc;

      if (current.spending >= result.predictedSpending) {
        setAnimatedValues({
          spending: result.predictedSpending,
          savings: result.actualSavings,
          budget: result.budgetUsed
        });
        clearInterval(timer);
      } else {
        setAnimatedValues({
          spending: Math.round(current.spending),
          savings: Math.round(current.savings),
          budget: Math.round(current.budget)
        });
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [result]);

  const pieData = Object.entries(result.categoryBreakdown).map(([name, value]) => ({
    name, value,
    color: ['#00D4FF', '#8B5CF6', '#22D3EE', '#F472B6', '#34D399', '#FBBF24', '#EF4444', '#A78BFA', '#FB923C'][
      ['Food', 'Transport', 'Shopping', 'Entertainment', 'Healthcare', 'Education', 'Utilities', 'Rent', 'Others'].indexOf(name) || 0
    ]
  }));

  const barData = [
    { name: 'Predicted', value: result.predictedSpending },
    { name: 'Budget', value: parseFloat(formData.budgetLimit) || 3000 },
    { name: 'Savings', value: result.actualSavings },
  ];

  const healthScore = Math.max(0, Math.min(100, 100 - result.budgetUsed * 0.5 + (result.actualSavings / (parseFloat(formData.income) || 4500)) * 50));

  const getIcon = (iconName) => {
    const icons = {
      alert: AlertTriangle,
      savings: PiggyBank,
      trend: TrendingUp,
      goal: Target,
      tip: Lightbulb,
      check: Award
    };
    return icons[iconName] || Lightbulb;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      transition={{ duration: 0.8 }}
      className="mt-16"
    >
      {/* Results Header */}
      <div className="text-center mb-12">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/10 border border-green-500/30 mb-4"
        >
          <Award className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400 font-medium">Analysis Complete</span>
        </motion.div>
        <h3 className="font-poppins text-3xl md:text-4xl font-bold text-white">
          Your <span className="text-gradient">Financial Insights</span>
        </h3>
      </div>

      {/* Main Results Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {/* Predicted Spending */}
        <motion.div
          className="glass-card-strong p-8 flex flex-col items-center"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-neon-blue" />
            Predicted Monthly Spending
          </h4>
          <CircularProgress 
            value={animatedValues.spending} 
            max={parseFloat(formData.income) || 5000} 
            color={result.budgetStatus.color}
            size={200}
            label={`$${animatedValues.spending}`}
            sublabel="Predicted"
          />
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }} className="mt-4 text-center">
            <span 
              className="px-4 py-1.5 rounded-full text-sm font-semibold"
              style={{ 
                backgroundColor: `${result.budgetStatus.color}20`,
                color: result.budgetStatus.color,
                border: `1px solid ${result.budgetStatus.color}40`
              }}
            >
              {result.budgetStatus.status}
            </span>
          </motion.div>
        </motion.div>

        {/* Savings & Budget */}
        <motion.div className="flex flex-col gap-6" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
          {/* Budget Usage */}
          <div className="glass-card-strong p-6">
            <h4 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
              <Target className="w-5 h-5 text-neon-purple" />
              Budget Utilization
            </h4>
            <div className="flex items-center gap-4">
              <CircularProgress value={animatedValues.budget} max={100} color={result.budgetUsed > 90 ? '#EF4444' : result.budgetUsed > 70 ? '#FBBF24' : '#34D399'} size={120} strokeWidth={8} label={`${animatedValues.budget}%`} sublabel="Used" />
              <div className="flex-1">
                <div className="text-sm text-white/50 mb-1">Budget Status</div>
                <div className="text-xl font-bold text-white">${result.predictedSpending} / ${formData.budgetLimit || 'N/A'}</div>
                <div className="text-xs text-white/40 mt-1">
                  {result.budgetUsed < 70 ? 'Well within budget' : result.budgetUsed < 90 ? 'Approaching limit' : 'Over budget risk'}
                </div>
              </div>
            </div>
          </div>

          {/* Savings Card */}
          <div className="glass-card-strong p-6">
            <h4 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
              <PiggyBank className="w-5 h-5 text-neon-cyan" />
              Savings Analysis
            </h4>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-3xl font-bold text-white">${result.actualSavings}</span>
              <span className="text-sm text-white/50">/month</span>
            </div>
            <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden mb-2">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-neon-blue to-neon-purple"
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, (result.actualSavings / (parseFloat(formData.savingsGoal) || 1000)) * 100)}%` }}
                transition={{ duration: 1.5, delay: 0.5 }}
              />
            </div>
            <div className="flex justify-between text-xs text-white/40">
              <span>Goal: ${formData.savingsGoal || 1000}</span>
              <span>Rate: {result.savingsRate}%</span>
            </div>
            {result.savingsPotential > 0 && (
              <div className="mt-2 text-xs text-yellow-400 flex items-center gap-1">
                <ArrowUpRight className="w-3 h-3" />
                Potential extra: ${result.savingsPotential}/month
              </div>
            )}
          </div>
        </motion.div>

        {/* AI Confidence & Health Score */}
        <motion.div className="glass-card-strong p-6" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.6 }}>
          <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-400" />
            AI Confidence
          </h4>
          <div className="flex flex-col items-center mb-6">
            <div className="relative w-40 h-40">
              <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                <circle cx="50" cy="50" r="45" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="8" />
                <motion.circle cx="50" cy="50" r="45" fill="none" stroke="#FBBF24" strokeWidth="8" strokeLinecap="round"
                  initial={{ strokeDasharray: "0 283" }}
                  animate={{ strokeDasharray: `${(result.confidence / 100) * 283} 283` }}
                  transition={{ duration: 2, ease: "easeOut" }}
                  style={{ filter: 'drop-shadow(0 0 10px rgba(251, 191, 36, 0.5))' }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold text-white">{result.confidence}%</span>
                <span className="text-xs text-white/50">Confidence</span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-white/50">Model Accuracy</span>
              <span className="text-white font-medium">99.2% R²</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-white/50">Algorithm</span>
              <span className="text-white font-medium">SVR (Support Vector)</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-white/50">MAE</span>
              <span className="text-white font-medium">$12.40</span>
            </div>
          </div>

          {/* Financial Health Score */}
          <div className="mt-6 pt-4 border-t border-white/10">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-white/50">Financial Health Score</span>
              <span className="text-lg font-bold text-neon-blue">{Math.round(healthScore)}/100</span>
            </div>
            <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-neon-blue to-neon-purple"
                initial={{ width: 0 }}
                animate={{ width: `${healthScore}%` }}
                transition={{ duration: 1.5, delay: 0.8 }}
              />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6 max-w-6xl mx-auto">
        {/* Category Pie Chart */}
        <motion.div className="glass-card-strong p-6" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8 }}>
          <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-neon-blue" />
            Category Breakdown
          </h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={5} dataKey="value">
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: 'rgba(11, 15, 26, 0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-3 mt-2 justify-center">
            {pieData.map((item) => (
              <div key={item.name} className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs text-white/60">{item.name}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Budget vs Actual Bar Chart */}
        <motion.div className="glass-card-strong p-6" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1 }}>
          <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-neon-purple" />
            Budget vs Predicted
          </h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="name" stroke="rgba(255,255,255,0.5)" />
                <YAxis stroke="rgba(255,255,255,0.5)" />
                <Tooltip contentStyle={{ backgroundColor: 'rgba(11, 15, 26, 0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }} />
                <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                  {barData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? '#00D4FF' : index === 1 ? '#8B5CF6' : '#34D399'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      {/* Recommendations */}
      <motion.div className="mt-6 max-w-6xl mx-auto" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.2 }}>
        <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-neon-purple" />
          AI-Powered Recommendations
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {result.recommendations.map((rec, index) => {
            const Icon = getIcon(rec.icon);
            return (
              <motion.div
                key={index}
                className="glass-card p-5 flex items-start gap-3"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.4 + index * 0.1 }}
                whileHover={{ y: -3, boxShadow: '0 0 20px rgba(139, 92, 246, 0.2)' }}
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${
                  rec.priority === 'high' ? 'bg-red-500/20' : rec.priority === 'medium' ? 'bg-yellow-500/20' : 'bg-green-500/20'
                }`}>
                  <Icon className={`w-5 h-5 ${
                    rec.priority === 'high' ? 'text-red-400' : rec.priority === 'medium' ? 'text-yellow-400' : 'text-green-400'
                  }`} />
                </div>
                <div>
                  <h5 className="text-sm font-semibold text-white mb-1">{rec.title}</h5>
                  <p className="text-sm text-white/60">{rec.description}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>
    </motion.div>
  );
};

export default PredictionResults;
