import React from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, Zap, TrendingUp, Shield, BarChart3, 
  PiggyBank, Bell, Sparkles
} from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'ML Spending Prediction',
    description: 'Advanced Support Vector Regression model predicts your monthly spending with 99.2% accuracy based on historical patterns.',
    color: '#00D4FF',
    delay: 0
  },
  {
    icon: Zap,
    title: 'Instant Expense Analysis',
    description: 'Real-time analysis of every transaction. Get immediate insights into spending patterns and category breakdowns.',
    color: '#8B5CF6',
    delay: 0.1
  },
  {
    icon: PiggyBank,
    title: 'Smart Saving Recommendations',
    description: 'AI-powered suggestions to optimize your savings rate and reach financial goals faster with personalized strategies.',
    color: '#34D399',
    delay: 0.2
  },
  {
    icon: BarChart3,
    title: 'Spending Pattern Detection',
    description: 'Automatically detect recurring patterns, seasonal trends, and anomalies in your spending behavior.',
    color: '#F472B6',
    delay: 0.3
  },
  {
    icon: Shield,
    title: 'Budget Suggestions',
    description: 'Intelligent budget allocation recommendations based on your income, lifestyle, and financial objectives.',
    color: '#FBBF24',
    delay: 0.4
  },
  {
    icon: Bell,
    title: 'Monthly Financial Insights',
    description: 'Comprehensive monthly reports with actionable insights, trend analysis, and personalized financial health scores.',
    color: '#22D3EE',
    delay: 0.5
  }
];

const FeaturesSection = () => {
  return (
    <section id="features" className="relative z-10 py-20 section-padding">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8 }}
      >
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-neon-cyan/10 border border-neon-cyan/30 mb-4"
          >
            <Sparkles className="w-4 h-4 text-neon-cyan" />
            <span className="text-sm text-neon-cyan font-medium">AI-Powered Features</span>
          </motion.div>
          <h2 className="font-poppins text-4xl md:text-5xl font-bold text-white mb-4">
            Why Choose <span className="text-gradient">AI Finance</span>
          </h2>
          <p className="text-white/50 max-w-2xl mx-auto">
            Leverage cutting-edge machine learning technology to transform how you manage, track, and optimize your personal finances.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="glass-card p-8 group cursor-pointer"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: feature.delay }}
              whileHover={{ 
                y: -8, 
                boxShadow: `0 0 40px ${feature.color}20`,
                borderColor: `${feature.color}40`
              }}
            >
              <motion.div
                className="w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-all duration-300"
                style={{ backgroundColor: `${feature.color}15` }}
                whileHover={{ scale: 1.1, rotate: 5 }}
              >
                <feature.icon 
                  className="w-7 h-7 transition-all duration-300" 
                  style={{ color: feature.color }}
                />
              </motion.div>

              <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-gradient transition-all duration-300">
                {feature.title}
              </h3>
              <p className="text-white/50 text-sm leading-relaxed">
                {feature.description}
              </p>

              <div 
                className="mt-6 h-0.5 w-0 group-hover:w-full transition-all duration-500 rounded-full"
                style={{ backgroundColor: feature.color }}
              />
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
};

export default FeaturesSection;
