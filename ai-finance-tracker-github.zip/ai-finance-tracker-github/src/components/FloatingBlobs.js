import React from 'react';
import { motion } from 'framer-motion';

const FloatingBlobs = () => {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      <motion.div
        className="absolute w-96 h-96 rounded-full bg-neon-blue/10 blur-3xl"
        animate={{ x: [0, 100, 0], y: [0, -50, 0], scale: [1, 1.2, 1] }}
        transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
        style={{ top: '10%', left: '10%' }}
      />
      <motion.div
        className="absolute w-80 h-80 rounded-full bg-neon-purple/10 blur-3xl"
        animate={{ x: [0, -80, 0], y: [0, 60, 0], scale: [1, 1.3, 1] }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
        style={{ top: '60%', right: '15%' }}
      />
      <motion.div
        className="absolute w-72 h-72 rounded-full bg-neon-cyan/10 blur-3xl"
        animate={{ x: [0, 60, 0], y: [0, 80, 0], scale: [1, 1.1, 1] }}
        transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
        style={{ bottom: '10%', left: '30%' }}
      />
    </div>
  );
};

export default FloatingBlobs;
