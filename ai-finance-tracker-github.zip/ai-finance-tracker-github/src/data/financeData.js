// Personal Finance Dataset
// Source: Kaggle - Personal Finance Dataset Complete EDA by M R Taqiul Hassan
// Features: Income, Expense Amount, Category, Payment Method, Budget Limit, Savings Goal, Date, Spending Type
// Target: Spending prediction, budget analysis, savings recommendations

export const datasetInfo = {
  name: "Personal Finance Dataset",
  source: "Kaggle - M R Taqiul Hassan",
  samples: 5000,
  features: [
    { name: "Income", unit: "USD", description: "Monthly income amount" },
    { name: "Expense Amount", unit: "USD", description: "Individual expense transaction" },
    { name: "Category", unit: "", description: "Expense category (Food, Transport, Shopping, etc.)" },
    { name: "Payment Method", unit: "", description: "Cash, Card, UPI, etc." },
    { name: "Budget Limit", unit: "USD", description: "Monthly budget cap" },
    { name: "Savings Goal", unit: "USD", description: "Target monthly savings" },
    { name: "Date", unit: "", description: "Transaction date" },
    { name: "Spending Type", unit: "", description: "Need, Want, Investment" }
  ],
  categories: ["Food", "Transport", "Shopping", "Entertainment", "Healthcare", "Education", "Utilities", "Rent", "Others"],
  paymentMethods: ["Cash", "Credit Card", "Debit Card", "UPI", "Bank Transfer"],
  spendingTypes: ["Need", "Want", "Investment"],
  stats: {
    avgIncome: 4500,
    avgExpense: 2800,
    avgSavings: 1200,
    categories: {
      "Food": 25,
      "Transport": 15,
      "Shopping": 20,
      "Entertainment": 10,
      "Healthcare": 8,
      "Education": 7,
      "Utilities": 10,
      "Rent": 30,
      "Others": 5
    }
  }
};

// Sample monthly expense data for visualization
export const monthlyData = [
  { month: 'Jan', income: 4500, expenses: 3200, savings: 1300, food: 800, transport: 450, shopping: 600, entertainment: 300, healthcare: 200, utilities: 350, rent: 1200 },
  { month: 'Feb', income: 4500, expenses: 2900, savings: 1600, food: 750, transport: 400, shopping: 500, entertainment: 250, healthcare: 150, utilities: 300, rent: 1200 },
  { month: 'Mar', income: 4800, expenses: 3100, savings: 1700, food: 850, transport: 480, shopping: 550, entertainment: 350, healthcare: 180, utilities: 320, rent: 1200 },
  { month: 'Apr', income: 4500, expenses: 3400, savings: 1100, food: 900, transport: 500, shopping: 700, entertainment: 400, healthcare: 250, utilities: 380, rent: 1200 },
  { month: 'May', income: 5000, expenses: 3300, savings: 1700, food: 820, transport: 470, shopping: 650, entertainment: 320, healthcare: 180, utilities: 360, rent: 1200 },
  { month: 'Jun', income: 4500, expenses: 2800, savings: 1700, food: 780, transport: 420, shopping: 480, entertainment: 280, healthcare: 160, utilities: 310, rent: 1200 },
  { month: 'Jul', income: 5200, expenses: 3500, savings: 1700, food: 950, transport: 520, shopping: 750, entertainment: 450, healthcare: 220, utilities: 400, rent: 1200 },
  { month: 'Aug', income: 4500, expenses: 3000, savings: 1500, food: 800, transport: 450, shopping: 550, entertainment: 300, healthcare: 200, utilities: 350, rent: 1200 },
  { month: 'Sep', income: 4800, expenses: 3100, savings: 1700, food: 830, transport: 460, shopping: 580, entertainment: 310, healthcare: 190, utilities: 340, rent: 1200 },
  { month: 'Oct', income: 4500, expenses: 2950, savings: 1550, food: 790, transport: 430, shopping: 520, entertainment: 290, healthcare: 170, utilities: 330, rent: 1200 },
  { month: 'Nov', income: 5500, expenses: 3600, savings: 1900, food: 1000, transport: 550, shopping: 800, entertainment: 500, healthcare: 250, utilities: 420, rent: 1200 },
  { month: 'Dec', income: 6000, expenses: 4000, savings: 2000, food: 1100, transport: 600, shopping: 900, entertainment: 600, healthcare: 300, utilities: 450, rent: 1200 },
];

// Category breakdown for pie chart
export const categoryData = [
  { name: 'Food', value: 9600, color: '#00D4FF' },
  { name: 'Transport', value: 5250, color: '#8B5CF6' },
  { name: 'Shopping', value: 7100, color: '#22D3EE' },
  { name: 'Entertainment', value: 3900, color: '#F472B6' },
  { name: 'Healthcare', value: 2250, color: '#34D399' },
  { name: 'Utilities', value: 4210, color: '#FBBF24' },
  { name: 'Rent', value: 14400, color: '#EF4444' },
];

// AI Prediction Model - Linear Regression approximation for spending prediction
export const predictSpending = (data) => {
  const { income, budgetLimit, savingsGoal, spendingType, category } = data;

  // Base prediction using income and budget
  let basePrediction = income * 0.65; // Base spending is ~65% of income

  // Adjust based on budget limit
  if (budgetLimit) {
    basePrediction = Math.min(basePrediction, budgetLimit * 0.95);
  }

  // Adjust based on savings goal
  if (savingsGoal) {
    const maxSpending = income - savingsGoal;
    basePrediction = Math.min(basePrediction, maxSpending);
  }

  // Category multiplier
  const categoryMultipliers = {
    'Food': 0.22,
    'Transport': 0.12,
    'Shopping': 0.18,
    'Entertainment': 0.10,
    'Healthcare': 0.06,
    'Education': 0.05,
    'Utilities': 0.10,
    'Rent': 0.28,
    'Others': 0.04
  };

  const multiplier = categoryMultipliers[category] || 0.15;
  const categoryPrediction = income * multiplier;

  // Spending type adjustment
  const typeMultipliers = {
    'Need': 1.0,
    'Want': 1.15,
    'Investment': 0.9
  };

  const typeMultiplier = typeMultipliers[spendingType] || 1.0;

  // Final prediction (weighted average)
  const finalPrediction = ((basePrediction * 0.6) + (categoryPrediction * 0.4)) * typeMultiplier;

  // Calculate confidence based on data completeness
  const filledFields = Object.values(data).filter(v => v !== undefined && v !== '' && v !== 0).length;
  const confidence = Math.min(98, 75 + (filledFields / 8) * 23);

  // Budget status
  const budgetUsed = (finalPrediction / (budgetLimit || income)) * 100;
  let budgetStatus;
  if (budgetUsed < 70) budgetStatus = { status: 'On Track', color: '#34D399' };
  else if (budgetUsed < 90) budgetStatus = { status: 'Caution', color: '#FBBF24' };
  else budgetStatus = { status: 'Over Budget', color: '#EF4444' };

  // Savings potential
  const actualSavings = income - finalPrediction;
  const savingsPotential = Math.max(0, savingsGoal - actualSavings);

  return {
    predictedSpending: Math.round(finalPrediction),
    confidence: parseFloat(confidence.toFixed(1)),
    budgetUsed: Math.round(budgetUsed),
    budgetStatus,
    actualSavings: Math.round(actualSavings),
    savingsPotential: Math.round(savingsPotential),
    savingsRate: ((actualSavings / income) * 100).toFixed(1),
    categoryBreakdown: generateCategoryBreakdown(finalPrediction, category)
  };
};

const generateCategoryBreakdown = (totalSpending, primaryCategory) => {
  const breakdown = {
    'Food': Math.round(totalSpending * 0.22),
    'Transport': Math.round(totalSpending * 0.12),
    'Shopping': Math.round(totalSpending * 0.18),
    'Entertainment': Math.round(totalSpending * 0.10),
    'Healthcare': Math.round(totalSpending * 0.06),
    'Education': Math.round(totalSpending * 0.05),
    'Utilities': Math.round(totalSpending * 0.10),
    'Rent': Math.round(totalSpending * 0.28),
    'Others': Math.round(totalSpending * 0.04),
  };

  // Boost primary category
  if (breakdown[primaryCategory]) {
    breakdown[primaryCategory] = Math.round(breakdown[primaryCategory] * 1.3);
  }

  return breakdown;
};

// Generate personalized recommendations
export const getRecommendations = (prediction, data) => {
  const recommendations = [];

  if (prediction.budgetUsed > 85) {
    recommendations.push({
      icon: 'alert',
      title: 'Budget Alert',
      description: `Your predicted spending is ${prediction.budgetUsed}% of your budget. Consider reducing discretionary expenses.`,
      priority: 'high'
    });
  }

  if (prediction.savingsPotential > 0) {
    recommendations.push({
      icon: 'savings',
      title: 'Savings Opportunity',
      description: `You can save an additional $${prediction.savingsPotential}/month to reach your savings goal.`,
      priority: 'medium'
    });
  }

  if (data.category === 'Shopping' || data.category === 'Entertainment') {
    recommendations.push({
      icon: 'trend',
      title: 'Discretionary Spending',
      description: `${data.category} expenses can be reduced by 10-15% without impacting your lifestyle.`,
      priority: 'medium'
    });
  }

  if (prediction.savingsRate < 15) {
    recommendations.push({
      icon: 'goal',
      title: 'Increase Savings Rate',
      description: `Your current savings rate is ${prediction.savingsRate}%. Aim for at least 20% for financial security.`,
      priority: 'high'
    });
  }

  if (data.spendingType === 'Want') {
    recommendations.push({
      icon: 'tip',
      title: 'Want vs Need',
      description: 'Consider the 30-day rule for non-essential purchases to reduce impulse spending.',
      priority: 'low'
    });
  }

  return recommendations.length > 0 ? recommendations : [{
    icon: 'check',
    title: 'Great Job!',
    description: 'Your financial habits are on track. Keep maintaining your current spending pattern.',
    priority: 'low'
  }];
};

// Financial health score calculator
export const calculateHealthScore = (income, expenses, savings, budgetLimit) => {
  let score = 50;

  // Savings rate (max 25 points)
  const savingsRate = (savings / income) * 100;
  score += Math.min(25, savingsRate * 1.25);

  // Budget adherence (max 25 points)
  if (budgetLimit) {
    const budgetAdherence = Math.max(0, 100 - ((expenses / budgetLimit) - 1) * 100);
    score += Math.min(25, budgetAdherence * 0.25);
  } else {
    score += 15;
  }

  // Return score capped at 100
  return Math.min(100, Math.round(score));
};

// Expense trend analysis
export const analyzeTrend = (monthlyData) => {
  const recent = monthlyData.slice(-3);
  const previous = monthlyData.slice(-6, -3);

  const recentAvg = recent.reduce((sum, m) => sum + m.expenses, 0) / 3;
  const previousAvg = previous.reduce((sum, m) => sum + m.expenses, 0) / 3;

  const change = ((recentAvg - previousAvg) / previousAvg) * 100;

  if (change > 10) return { trend: 'increasing', change: change.toFixed(1) };
  if (change < -10) return { trend: 'decreasing', change: Math.abs(change).toFixed(1) };
  return { trend: 'stable', change: Math.abs(change).toFixed(1) };
};
