import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import ParticleBackground from './components/ParticleBackground';
import FloatingBlobs from './components/FloatingBlobs';
import LoadingScreen from './components/LoadingScreen';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import ExpenseForm from './components/ExpenseForm';
import Dashboard from './components/Dashboard';
import FeaturesSection from './components/FeaturesSection';
import AboutSection from './components/AboutSection';
import TeamSection from './components/TeamSection';
import Footer from './components/Footer';

function App() {
  const [loading, setLoading] = useState(true);
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    if (!loading) {
      setTimeout(() => setShowContent(true), 300);
    }
  }, [loading]);

  const scrollToTrack = () => {
    const element = document.getElementById('track');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen bg-bg-dark overflow-x-hidden">
      {/* Background Effects */}
      <ParticleBackground />
      <FloatingBlobs />

      {/* Loading Screen */}
      <AnimatePresence>
        {loading && <LoadingScreen onComplete={() => setLoading(false)} />}
      </AnimatePresence>

      {/* Main Content */}
      {showContent && (
        <div className="relative z-10">
          <Navbar />
          <HeroSection onTrackClick={scrollToTrack} />
          <ExpenseForm />
          <Dashboard />
          <FeaturesSection />
          <AboutSection />
          <TeamSection />
          <Footer />
        </div>
      )}
    </div>
  );
}

export default App;
