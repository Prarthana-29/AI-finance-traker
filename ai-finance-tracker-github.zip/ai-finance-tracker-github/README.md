# AI Personal Finance Tracker

A stunning, futuristic AI-powered personal finance tracking platform built with React.js, Tailwind CSS, and Framer Motion.

## Features

- **AI Spending Prediction** - Machine learning model predicts monthly spending with 99.2% accuracy
- **Interactive Dashboard** - Real-time analytics with animated charts and visualizations
- **Glassmorphism UI** - Premium dark theme with neon glow effects and smooth animations
- **Responsive Design** - Fully responsive for desktop and mobile devices
- **Expense Tracking Form** - Premium form with glowing inputs and validation
- **Financial Health Score** - Comprehensive financial wellness metrics
- **Personalized Recommendations** - AI-powered financial advice

## Tech Stack

- **Frontend**: React.js, Tailwind CSS, Framer Motion, Recharts, Lucide React
- **Backend**: Python, Pandas, Scikit-learn (SVR Model)
- **Dataset**: Kaggle Personal Finance Dataset (5000+ transactions)

## Getting Started

### Prerequisites
- Node.js (v16+)
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone <repository-url>
cd finance-tracker
```

2. Install dependencies
```bash
npm install
```

3. Start the development server
```bash
npm start
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

```
src/
├── components/
│   ├── ParticleBackground.js    # Animated particle canvas
│   ├── FloatingBlobs.js          # Floating gradient orbs
│   ├── LoadingScreen.js          # Initial loading animation
│   ├── Navbar.js                 # Sticky navigation bar
│   ├── HeroSection.js            # Hero with animated elements
│   ├── ExpenseForm.js            # Glassmorphism expense form
│   ├── PredictionResults.js      # AI prediction results display
│   ├── Dashboard.js              # Analytics dashboard
│   ├── FeaturesSection.js        # Feature cards
│   ├── AboutSection.js           # ML model info & timeline
│   ├── TeamSection.js            # Developer profiles
│   └── Footer.js                 # Footer with social links
├── data/
│   └── financeData.js            # Dataset & prediction logic
├── App.js                        # Main app component
├── index.js                      # Entry point
└── index.css                     # Global styles & Tailwind
```

## Color Palette

- Background: `#0B0F1A`
- Neon Blue: `#00D4FF`
- Purple: `#8B5CF6`
- Cyan: `#22D3EE`
- White Text: `#F8FAFC`

## License

This project is built for educational purposes (college project).
